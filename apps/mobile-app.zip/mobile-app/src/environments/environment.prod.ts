export const environment = {
  production: true,
  apiUrl: 'https://api.example.com/api',
  socketUrl: 'https://api.example.com',
};
