import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {
  IonContent, IonHeader, IonToolbar, IonTitle,
  IonButton, IonText,
} from '@ionic/angular/standalone';

@Component({
  selector: 'app-onboarding-ciudad',
  standalone: true,
  imports: [IonContent, IonHeader, IonToolbar, IonTitle, IonButton, IonText],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Bienvenido</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding ion-text-center">
      <div style="margin-top: 80px;">
        <ion-text>
          <h1>Predictor de Sociales</h1>
          <p>Descubre cómo será el ambiente antes de salir a bailar.</p>
          <p><strong>Ciudad:</strong> Cartagena</p>
        </ion-text>
        <ion-button expand="block" style="margin-top: 32px;" (click)="next()">
          Empezar — Soy de Cartagena
        </ion-button>
      </div>
    </ion-content>
  `,
})
export class OnboardingCiudadPage {
  constructor(private router: Router) {}

  next() {
    this.router.navigate(['/onboarding/rol']);
  }
}
