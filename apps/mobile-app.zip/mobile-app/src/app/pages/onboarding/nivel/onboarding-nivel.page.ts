import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonContent, IonHeader, IonToolbar, IonTitle,
  IonButton, IonText, IonList, IonItem, IonLabel, IonRadioGroup, IonRadio,
} from '@ionic/angular/standalone';
import { Nivel } from '@shared/types';
import { OnboardingStateService } from '../../../services/onboarding-state.service';

const NIVELES: { value: Nivel; label: string }[] = [
  { value: 'nuevo', label: 'Nuevo — primeras clases' },
  { value: 'iniciacion', label: 'Iniciación — bases sólidas' },
  { value: 'social_comodo', label: 'Social cómodo — bailo en pista' },
  { value: 'intermedio', label: 'Intermedio — aplico técnica' },
  { value: 'avanzado', label: 'Avanzado — nivel alto' },
];

@Component({
  selector: 'app-onboarding-nivel',
  standalone: true,
  imports: [
    CommonModule, FormsModule, IonContent, IonHeader, IonToolbar, IonTitle,
    IonButton, IonText, IonList, IonItem, IonLabel, IonRadioGroup, IonRadio,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Paso 3 de 4 — Tu nivel</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-text><h2>¿Cómo describes tu nivel?</h2></ion-text>

      <ion-list>
        <ion-radio-group [(ngModel)]="selected">
          <ion-item *ngFor="let n of niveles">
            <ion-label>{{ n.label }}</ion-label>
            <ion-radio slot="end" [value]="n.value"></ion-radio>
          </ion-item>
        </ion-radio-group>
      </ion-list>

      <ion-button expand="block" [disabled]="!selected" (click)="next()" style="margin-top: 16px;">
        Siguiente
      </ion-button>
    </ion-content>
  `,
})
export class OnboardingNivelPage {
  niveles = NIVELES;
  selected: Nivel | null = null;

  constructor(private router: Router, private state: OnboardingStateService) {
    this.selected = this.state.get().nivel;
  }

  next() {
    if (!this.selected) return;
    this.state.set({ nivel: this.selected });
    this.router.navigate(['/onboarding/estilos']);
  }
}
