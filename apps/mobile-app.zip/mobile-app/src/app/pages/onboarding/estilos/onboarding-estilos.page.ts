import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonContent, IonHeader, IonToolbar, IonTitle, IonButton, IonText,
  IonChip, IonLabel, IonItem, IonInput, IonList, IonToast,
} from '@ionic/angular/standalone';
import { Estilo } from '@shared/types';
import { OnboardingStateService } from '../../../services/onboarding-state.service';
import { AuthService } from '../../../services/auth.service';

const ALL_ESTILOS: { value: Estilo; label: string }[] = [
  { value: 'bachata_sensual', label: 'Bachata Sensual' },
  { value: 'bachata_tradicional', label: 'Bachata Tradicional' },
  { value: 'salsa_linea', label: 'Salsa en Línea' },
  { value: 'salsa_cubana', label: 'Salsa Cubana' },
];

@Component({
  selector: 'app-onboarding-estilos',
  standalone: true,
  imports: [
    CommonModule, FormsModule, IonContent, IonHeader, IonToolbar, IonTitle,
    IonButton, IonText, IonChip, IonLabel, IonItem, IonInput, IonList, IonToast,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Paso 4 de 4 — Estilos</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-text><h2>¿Qué estilos bailas?</h2><p>Selecciona al menos uno.</p></ion-text>

      <div style="display: flex; flex-wrap: wrap; gap: 8px; margin: 16px 0;">
        <ion-chip
          *ngFor="let e of estilos"
          [color]="isSelected(e.value) ? 'primary' : 'medium'"
          (click)="toggle(e.value)">
          <ion-label>{{ e.label }}</ion-label>
        </ion-chip>
      </div>

      <ion-list lines="none">
        <ion-item>
          <ion-label position="stacked">Academia principal (opcional)</ion-label>
          <ion-input [(ngModel)]="academia" placeholder="Ej. Academia de Salsa Cartagena"></ion-input>
        </ion-item>
      </ion-list>

      <ion-list lines="none" style="margin-top: 8px;">
        <ion-item>
          <ion-label position="stacked">Tu alias</ion-label>
          <ion-input [(ngModel)]="alias" placeholder="Ej. salsa_king" required></ion-input>
        </ion-item>
      </ion-list>

      <ion-button
        expand="block"
        style="margin-top: 16px;"
        [disabled]="selected.length === 0 || !alias.trim() || loading"
        (click)="finish()">
        {{ loading ? 'Creando perfil...' : 'Entrar a la app' }}
      </ion-button>

      <ion-toast
        [isOpen]="!!error"
        [message]="error"
        duration="3000"
        color="danger"
        (didDismiss)="error = ''">
      </ion-toast>
    </ion-content>
  `,
})
export class OnboardingEstilosPage {
  estilos = ALL_ESTILOS;
  selected: Estilo[] = [];
  academia = '';
  alias = '';
  loading = false;
  error = '';

  constructor(
    private router: Router,
    private state: OnboardingStateService,
    private authService: AuthService
  ) {
    this.selected = [...this.state.get().estilos];
    this.academia = this.state.get().academia;
  }

  isSelected(e: Estilo): boolean {
    return this.selected.includes(e);
  }

  toggle(e: Estilo): void {
    if (this.isSelected(e)) {
      this.selected = this.selected.filter((s) => s !== e);
    } else {
      this.selected = [...this.selected, e];
    }
  }

  finish(): void {
    const onboarding = this.state.get();
    if (!onboarding.rol || !onboarding.nivel || this.selected.length === 0 || !this.alias.trim()) return;

    this.loading = true;
    this.authService
      .register({
        alias: this.alias.trim(),
        rol: onboarding.rol,
        nivel: onboarding.nivel,
        estilos: this.selected,
        academia: this.academia.trim() || undefined,
      })
      .subscribe({
        next: () => {
          this.state.reset();
          this.router.navigate(['/tabs/home'], { replaceUrl: true });
        },
        error: (err) => {
          this.loading = false;
          this.error = err?.error?.message ?? 'Error al crear el perfil.';
        },
      });
  }
}
