import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  IonContent, IonHeader, IonToolbar, IonTitle,
  IonButton, IonText, IonCard, IonCardHeader, IonCardTitle, IonCardContent,
} from '@ionic/angular/standalone';
import { Rol } from '@shared/types';
import { OnboardingStateService } from '../../../services/onboarding-state.service';

const ROLES: { value: Rol; label: string; description: string }[] = [
  { value: 'leader', label: 'Leader', description: 'Llevo en pista' },
  { value: 'follower', label: 'Follower', description: 'Me dejo llevar' },
  { value: 'switch', label: 'Switch', description: 'Bailo los dos roles' },
];

@Component({
  selector: 'app-onboarding-rol',
  standalone: true,
  imports: [
    CommonModule, IonContent, IonHeader, IonToolbar, IonTitle,
    IonButton, IonText, IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Paso 2 de 4 — Tu rol</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-text><h2>¿Qué rol bailas?</h2></ion-text>

      <ion-card
        *ngFor="let r of roles"
        [style.border]="selected === r.value ? '2px solid var(--ion-color-primary)' : '2px solid transparent'"
        (click)="selected = r.value"
        button>
        <ion-card-header>
          <ion-card-title>{{ r.label }}</ion-card-title>
        </ion-card-header>
        <ion-card-content>{{ r.description }}</ion-card-content>
      </ion-card>

      <ion-button expand="block" [disabled]="!selected" (click)="next()" style="margin-top: 16px;">
        Siguiente
      </ion-button>
    </ion-content>
  `,
})
export class OnboardingRolPage {
  roles = ROLES;
  selected: Rol | null = null;

  constructor(private router: Router, private state: OnboardingStateService) {
    this.selected = this.state.get().rol;
  }

  next() {
    if (!this.selected) return;
    this.state.set({ rol: this.selected });
    this.router.navigate(['/onboarding/nivel']);
  }
}
