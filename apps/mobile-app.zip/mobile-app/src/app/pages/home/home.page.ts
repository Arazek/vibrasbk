import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonSpinner, IonText, IonButton, IonRefresher, IonRefresherContent,
} from '@ionic/angular/standalone';
import { WeeklyEvent } from '@shared/types';
import { EventsService } from '../../services/events.service';
import { EventCardComponent } from '../../components/event-card/event-card.component';

const DAY_NAMES = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule, IonHeader, IonToolbar, IonTitle, IonContent,
    IonSpinner, IonText, IonButton,
    IonRefresher, IonRefresherContent,
    EventCardComponent,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Agenda Semanal</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content>
      <ion-refresher slot="fixed" (ionRefresh)="load($event)">
        <ion-refresher-content></ion-refresher-content>
      </ion-refresher>

      <div *ngIf="loading" class="ion-text-center ion-padding">
        <ion-spinner></ion-spinner>
      </div>

      <div *ngIf="error" class="ion-padding">
        <ion-text color="danger"><p>{{ error }}</p></ion-text>
        <ion-button (click)="load(null)">Reintentar</ion-button>
      </div>

      <div *ngIf="!loading && !error">
        <div *ngFor="let group of grouped">
          <div style="padding: 12px 16px 0; font-weight: 600; color: var(--ion-color-medium);">
            {{ group.dayName }}
          </div>
          <app-event-card *ngFor="let ev of group.events" [event]="ev"></app-event-card>
        </div>

        <div *ngIf="grouped.length === 0" class="ion-padding ion-text-center">
          <ion-text color="medium"><p>No hay eventos esta semana.</p></ion-text>
        </div>
      </div>
    </ion-content>
  `,
})
export class HomePage implements OnInit {
  loading = true;
  error = '';
  grouped: { dayName: string; events: WeeklyEvent[] }[] = [];

  constructor(private eventsService: EventsService, private router: Router) {}

  ngOnInit() {
    this.load(null);
  }

  load(refresher: any) {
    this.loading = !refresher;
    this.error = '';
    this.eventsService.getWeeklyEvents().subscribe({
      next: (events) => {
        this.grouped = this.groupByDay(events);
        this.loading = false;
        refresher?.complete();
      },
      error: () => {
        this.error = 'No se pudo cargar la agenda.';
        this.loading = false;
        refresher?.complete();
      },
    });
  }

  private groupByDay(events: WeeklyEvent[]): { dayName: string; events: WeeklyEvent[] }[] {
    const map = new Map<number, WeeklyEvent[]>();
    for (const ev of events) {
      const day = new Date(ev.eventDate).getDay();
      const normalized = day === 0 ? 6 : day - 1;
      if (!map.has(normalized)) map.set(normalized, []);
      map.get(normalized)!.push(ev);
    }
    return Array.from(map.entries())
      .sort(([a], [b]) => a - b)
      .map(([day, evs]) => ({ dayName: DAY_NAMES[day], events: evs }));
  }
}
