import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonButtons,
  IonButton, IonSpinner, IonText, IonList, IonItem, IonLabel,
  IonSelect, IonSelectOption, IonChip, IonToast,
} from '@ionic/angular/standalone';
import { UserProfile, Nivel, Estilo } from '@shared/types';
import { ProfileService } from '../../services/profile.service';
import { AuthService } from '../../services/auth.service';

const ALL_ESTILOS: { value: Estilo; label: string }[] = [
  { value: 'bachata_sensual', label: 'Bachata Sensual' },
  { value: 'bachata_tradicional', label: 'Bachata Tradicional' },
  { value: 'salsa_linea', label: 'Salsa en Línea' },
  { value: 'salsa_cubana', label: 'Salsa Cubana' },
];

const NIVEL_OPTIONS: { value: Nivel; label: string }[] = [
  { value: 'nuevo',         label: 'Nuevo' },
  { value: 'iniciacion',    label: 'Iniciación' },
  { value: 'social_comodo', label: 'Social cómodo' },
  { value: 'intermedio',    label: 'Intermedio' },
  { value: 'avanzado',      label: 'Avanzado' },
];

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    IonHeader, IonToolbar, IonTitle, IonContent, IonButtons,
    IonButton, IonSpinner, IonText, IonList, IonItem, IonLabel,
    IonSelect, IonSelectOption, IonChip, IonToast,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Mi Perfil</ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="logout()">Salir</ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div *ngIf="loading" class="ion-text-center"><ion-spinner></ion-spinner></div>

      <div *ngIf="profile && !loading">
        <!-- Read-only fields -->
        <ion-text>
          <h2>{{ profile.alias }}</h2>
          <p>{{ profile.ciudad }} · {{ profile.rol | titlecase }}</p>
        </ion-text>

        <!-- Editable fields -->
        <ion-list>
          <ion-item>
            <ion-label>Nivel</ion-label>
            <ion-select [(ngModel)]="selectedNivel" interface="action-sheet">
              <ion-select-option *ngFor="let n of nivelOptions" [value]="n.value">
                {{ n.label }}
              </ion-select-option>
            </ion-select>
          </ion-item>
        </ion-list>

        <ion-text><p style="margin: 16px 0 8px; font-weight: 500;">Estilos</p></ion-text>
        <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px;">
          <ion-chip
            *ngFor="let e of estiloOptions"
            [color]="isSelected(e.value) ? 'primary' : 'medium'"
            (click)="toggleEstilo(e.value)">
            <ion-label>{{ e.label }}</ion-label>
          </ion-chip>
        </div>

        <ion-button expand="block" [disabled]="saving || selectedEstilos.length === 0" (click)="save()">
          {{ saving ? 'Guardando...' : 'Guardar cambios' }}
        </ion-button>
      </div>

      <ion-toast
        [isOpen]="!!toastMsg"
        [message]="toastMsg"
        duration="2000"
        (didDismiss)="toastMsg = ''">
      </ion-toast>
    </ion-content>
  `,
})
export class ProfilePage implements OnInit {
  profile: UserProfile | null = null;
  loading = true;
  saving = false;
  toastMsg = '';

  selectedNivel: Nivel = 'social_comodo';
  selectedEstilos: Estilo[] = [];

  nivelOptions = NIVEL_OPTIONS;
  estiloOptions = ALL_ESTILOS;

  constructor(
    private profileService: ProfileService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.profileService.getProfile().subscribe({
      next: (p) => {
        this.profile = p;
        this.selectedNivel = p.nivel;
        this.selectedEstilos = [...p.estilos];
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.toastMsg = 'No se pudo cargar el perfil.';
      },
    });
  }

  isSelected(e: Estilo): boolean {
    return this.selectedEstilos.includes(e);
  }

  toggleEstilo(e: Estilo): void {
    if (this.isSelected(e)) {
      this.selectedEstilos = this.selectedEstilos.filter((s) => s !== e);
    } else {
      this.selectedEstilos = [...this.selectedEstilos, e];
    }
  }

  save() {
    this.saving = true;
    this.profileService.updateProfile({ nivel: this.selectedNivel, estilos: this.selectedEstilos }).subscribe({
      next: (p) => {
        this.profile = p;
        this.saving = false;
        this.toastMsg = 'Perfil actualizado.';
      },
      error: () => {
        this.saving = false;
        this.toastMsg = 'Error al guardar.';
      },
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/onboarding/ciudad'], { replaceUrl: true });
  }
}
