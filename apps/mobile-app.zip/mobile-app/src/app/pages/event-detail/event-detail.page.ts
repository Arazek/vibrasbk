import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonBackButton, IonButtons,
  IonButton, IonSpinner, IonText, IonChip, IonLabel, IonToast,
} from '@ionic/angular/standalone';
import { WeeklyEvent, EventAnalytics, VoteEstado } from '@shared/types';
import { EventsService } from '../../services/events.service';
import { VotesService } from '../../services/votes.service';
import { AnalyticsPanelComponent } from '../../components/analytics-panel/analytics-panel.component';
import { ReplacePipe } from '../../pipes/replace.pipe';

const DAY_NAMES = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

@Component({
  selector: 'app-event-detail',
  standalone: true,
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent, IonBackButton, IonButtons,
    IonButton, IonSpinner, IonText, IonChip, IonLabel, IonToast,
    AnalyticsPanelComponent, ReplacePipe,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-buttons slot="start">
          <ion-back-button defaultHref="/tabs/home"></ion-back-button>
        </ion-buttons>
        <ion-title>{{ event?.venue?.nombre ?? 'Evento' }}</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div *ngIf="loading" class="ion-text-center">
        <ion-spinner></ion-spinner>
      </div>

      <div *ngIf="event && !loading">

        <!-- Event info -->
        <ion-text>
          <h2>{{ event.venue.nombre }}</h2>
          <p>{{ dayName }} · {{ event.horaInicio }}</p>
        </ion-text>

        <div style="display: flex; flex-wrap: wrap; gap: 4px; margin: 8px 0 16px;">
          <ion-chip *ngFor="let e of event.estilos" color="secondary">
            <ion-label>{{ e | replace:'_':' ' }}</ion-label>
          </ion-chip>
        </div>

        <p style="color: var(--ion-color-medium); font-size: 13px;">
          {{ event.totalInteresados }} personas interesadas
        </p>

        <!-- Vote section -->
        <div style="margin: 24px 0;">
          <ion-text><h3>¿Irás a este social?</h3></ion-text>

          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <ion-button
              [fill]="event.userVote === 'voy' ? 'solid' : 'outline'"
              color="success"
              [disabled]="voting || !canEdit"
              (click)="vote('voy')">
              Voy
            </ion-button>
            <ion-button
              [fill]="event.userVote === 'tal_vez' ? 'solid' : 'outline'"
              color="warning"
              [disabled]="voting || !canEdit"
              (click)="vote('tal_vez')">
              Tal vez
            </ion-button>
            <ion-button
              [fill]="event.userVote === 'no_voy' ? 'solid' : 'outline'"
              color="medium"
              [disabled]="voting || !canEdit"
              (click)="vote('no_voy')">
              No iré
            </ion-button>
          </div>

          <p *ngIf="!canEdit" style="font-size:12px; color: var(--ion-color-medium); margin-top:8px;">
            El voto ya no es editable (menos de 2h antes del evento).
          </p>
        </div>

        <!-- Analytics (unlocked after voy/tal_vez) -->
        <div *ngIf="analytics">
          <app-analytics-panel [analytics]="analytics"></app-analytics-panel>
        </div>

        <div *ngIf="analyticsLoading" class="ion-text-center">
          <ion-spinner name="dots"></ion-spinner>
        </div>

        <div *ngIf="showAnalyticsHint && !analytics" style="margin-top: 16px;">
          <ion-text color="medium">
            <p>Vota "Voy" o "Tal vez" para ver la predicción del ambiente.</p>
          </ion-text>
        </div>
      </div>

      <ion-toast
        [isOpen]="!!toastMsg"
        [message]="toastMsg"
        duration="2500"
        (didDismiss)="toastMsg = ''">
      </ion-toast>
    </ion-content>
  `,
})
export class EventDetailPage implements OnInit {
  event: WeeklyEvent | null = null;
  analytics: EventAnalytics | null = null;
  loading = true;
  voting = false;
  analyticsLoading = false;
  showAnalyticsHint = false;
  toastMsg = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private eventsService: EventsService,
    private votesService: VotesService
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.eventsService.getEventDetail(id).subscribe({
      next: (ev) => {
        this.event = ev as WeeklyEvent;
        this.loading = false;
        this.showAnalyticsHint = true;
        if (ev.userVote === 'voy' || ev.userVote === 'tal_vez') {
          this.loadAnalytics(id);
        }
      },
      error: () => {
        this.loading = false;
        this.toastMsg = 'No se pudo cargar el evento.';
      },
    });
  }

  get canEdit(): boolean {
    if (!this.event) return false;
    const start = new Date(this.event.eventStart);
    return new Date() < new Date(start.getTime() - 2 * 60 * 60 * 1000);
  }

  get dayName(): string {
    if (!this.event) return '';
    const d = new Date(this.event.eventDate).getDay();
    return DAY_NAMES[d === 0 ? 6 : d - 1];
  }

  vote(estado: VoteEstado) {
    if (!this.event || this.voting) return;
    this.voting = true;
    const existingVoteId = this.event.userVoteId;

    const request$ = existingVoteId
      ? this.votesService.updateVote(existingVoteId, estado)
      : this.votesService.castVote(this.event.id, estado);

    request$.subscribe({
      next: (vote) => {
        this.voting = false;
        if (this.event) {
          this.event = { ...this.event, userVote: estado, userVoteId: vote.id };
        }
        if (estado === 'voy' || estado === 'tal_vez') {
          this.loadAnalytics(this.event!.id);
        } else {
          this.analytics = null;
        }
      },
      error: (err) => {
        this.voting = false;
        this.toastMsg = err?.error?.message ?? 'Error al votar.';
      },
    });
  }

  private loadAnalytics(eventId: string) {
    this.analyticsLoading = true;
    this.eventsService.getAnalytics(eventId).subscribe({
      next: (a) => {
        this.analytics = a;
        this.analyticsLoading = false;
      },
      error: () => {
        this.analyticsLoading = false;
      },
    });
  }
}
