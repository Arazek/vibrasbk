import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonBadge, IonProgressBar, IonText,
} from '@ionic/angular/standalone';
import { EventAnalytics, Ambiente, Nivel } from '@shared/types';

const AMBIENTE_COLOR: Record<Ambiente, string> = {
  flojo:     'medium',
  normal:    'warning',
  animado:   'success',
  muy_lleno: 'danger',
};

const AMBIENTE_LABEL: Record<Ambiente, string> = {
  flojo:     'Flojo',
  normal:    'Normal',
  animado:   'Animado',
  muy_lleno: 'Muy lleno',
};

const NIVEL_LABELS: Record<Nivel, string> = {
  nuevo:         'Nuevo',
  iniciacion:    'Iniciación',
  social_comodo: 'Social cómodo',
  intermedio:    'Intermedio',
  avanzado:      'Avanzado',
};

const NIVEL_ORDER: Nivel[] = ['nuevo', 'iniciacion', 'social_comodo', 'intermedio', 'avanzado'];

const BALANCE_LABEL: Record<string, string> = {
  equilibrado:       'Equilibrado',
  faltan_leaders:    'Faltan leaders',
  faltan_followers:  'Faltan followers',
};

@Component({
  selector: 'app-analytics-panel',
  standalone: true,
  imports: [
    CommonModule, IonCard, IonCardHeader, IonCardTitle,
    IonCardContent, IonBadge, IonProgressBar, IonText,
  ],
  template: `
    <ion-card>
      <ion-card-header>
        <ion-card-title>Predicción</ion-card-title>
      </ion-card-header>
      <ion-card-content>

        <!-- Ambiente -->
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 16px;">
          <ion-badge [color]="ambienteColor">{{ ambienteLabel }}</ion-badge>
          <span style="font-size:13px; color: var(--ion-color-medium);">
            ~{{ analytics.asistenciaEstimada | number:'1.0-0' }} personas esperadas
          </span>
        </div>

        <!-- Role balance -->
        <div style="margin-bottom: 12px;">
          <ion-text color="medium"><small>Balance de roles</small></ion-text>
          <p style="margin: 4px 0; font-weight: 500;">{{ balanceLabel }}</p>
        </div>

        <!-- Level distribution -->
        <ion-text color="medium"><small>Nivel esperado</small></ion-text>
        <div *ngFor="let nivel of nivelOrder" style="margin: 4px 0;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
            <small>{{ nivelLabels[nivel] }}</small>
            <small>{{ analytics.nivelDistribution[nivel] }}</small>
          </div>
          <ion-progress-bar
            [value]="getBar(nivel)"
            color="primary">
          </ion-progress-bar>
        </div>

        <!-- Recommendation -->
        <div style="margin-top: 16px; padding: 12px; background: var(--ion-color-light); border-radius: 8px;">
          <ion-text><p style="margin: 0;">{{ analytics.recommendation }}</p></ion-text>
        </div>

      </ion-card-content>
    </ion-card>
  `,
})
export class AnalyticsPanelComponent {
  @Input() analytics!: EventAnalytics;

  nivelOrder = NIVEL_ORDER;
  nivelLabels = NIVEL_LABELS;

  get ambienteColor(): string {
    return AMBIENTE_COLOR[this.analytics.ambiente];
  }

  get ambienteLabel(): string {
    return AMBIENTE_LABEL[this.analytics.ambiente];
  }

  get balanceLabel(): string {
    return BALANCE_LABEL[this.analytics.roleBalance] ?? this.analytics.roleBalance;
  }

  get maxNivel(): number {
    const vals = Object.values(this.analytics.nivelDistribution);
    return Math.max(1, ...vals);
  }

  getBar(nivel: Nivel): number {
    return (this.analytics.nivelDistribution[nivel] ?? 0) / this.maxNivel;
  }
}
