import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent,
  IonBadge, IonChip, IonLabel,
} from '@ionic/angular/standalone';
import { ReplacePipe } from '../../pipes/replace.pipe';
import { WeeklyEvent, Ambiente } from '@shared/types';

const AMBIENTE_COLOR: Record<Ambiente, string> = {
  flojo:     '#9e9e9e',
  normal:    '#ffc107',
  animado:   '#4caf50',
  muy_lleno: '#f44336',
};

const AMBIENTE_LABEL: Record<Ambiente, string> = {
  flojo:     'Flojo',
  normal:    'Normal',
  animado:   'Animado',
  muy_lleno: 'Muy lleno',
};

const VOTE_LABEL: Record<string, string> = {
  voy:     '✓ Voy',
  tal_vez: '? Tal vez',
  no_voy:  '✗ No iré',
};

@Component({
  selector: 'app-event-card',
  standalone: true,
  imports: [
    CommonModule, IonCard, IonCardHeader, IonCardTitle,
    IonCardSubtitle, IonCardContent, IonBadge, IonChip, IonLabel, ReplacePipe,
  ],
  template: `
    <ion-card button (click)="open()">
      <ion-card-header>
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <div>
            <ion-card-title>{{ event.venue.nombre }}</ion-card-title>
            <ion-card-subtitle>{{ event.horaInicio }}</ion-card-subtitle>
          </div>
          <!-- Ambiente color dot -->
          <span
            [style.background]="ambienteColor"
            style="width:16px; height:16px; border-radius:50%; flex-shrink:0; margin-top:4px;">
          </span>
        </div>
      </ion-card-header>

      <ion-card-content>
        <!-- Styles chips -->
        <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px;">
          <ion-chip *ngFor="let e of event.estilos" color="secondary" style="height:24px;">
            <ion-label style="font-size:11px;">{{ e | replace:'_':' ' }}</ion-label>
          </ion-chip>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="font-size: 13px; color: var(--ion-color-medium);">
            {{ event.totalInteresados }} interesados · {{ ambienteLabel }}
          </span>
          <ion-badge *ngIf="event.userVote" color="primary">
            {{ voteLabel }}
          </ion-badge>
        </div>
      </ion-card-content>
    </ion-card>
  `,
})
export class EventCardComponent {
  @Input() event!: WeeklyEvent;

  constructor(private router: Router) {}

  get ambienteColor(): string {
    return AMBIENTE_COLOR[this.event.ambienteColor] ?? '#9e9e9e';
  }

  get ambienteLabel(): string {
    return AMBIENTE_LABEL[this.event.ambienteColor] ?? '';
  }

  get voteLabel(): string {
    return this.event.userVote ? VOTE_LABEL[this.event.userVote] : '';
  }

  open(): void {
    this.router.navigate(['/event', this.event.id]);
  }
}
