import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthResponse, Rol, Nivel, Estilo } from '@shared/types';

const TOKEN_KEY = 'auth_token';

export interface RegisterPayload {
  alias: string;
  rol: Rol;
  nivel: Nivel;
  estilos: Estilo[];
  academia?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly base = `${environment.apiUrl}/auth`;

  constructor(private http: HttpClient) {}

  register(payload: RegisterPayload): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/register`, payload).pipe(
      tap((res) => localStorage.setItem(TOKEN_KEY, res.accessToken))
    );
  }

  login(alias: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/login`, { alias }).pipe(
      tap((res) => localStorage.setItem(TOKEN_KEY, res.accessToken))
    );
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }
}
